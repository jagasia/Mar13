package mytag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class CopyrightTag extends SimpleTagSupport
{

	@Override
	public void doTag() throws JspException, IOException {
		//get reference to jsp writer and print a message
		//out is an implicit object in JSP only 	not here
		JspWriter out = getJspContext().getOut();
		out.print("Copyright: This product is protected....");
	}
	
}
