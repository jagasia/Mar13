package mytag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyTagSupport;

public class UpperTag extends BodyTagSupport
{
	String color;
	
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public int doEndTag() throws JspException {
		//get body content
		//get jsp write
		String bc=getBodyContent().getString();
		JspWriter out = getBodyContent().getEnclosingWriter();
		String output=bc.toUpperCase();
		output="<font color="+getColor()+">"+output+"</font>";
		try {
			out.print(output);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return super.doEndTag();
	}
	
}
